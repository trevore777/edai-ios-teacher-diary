import SwiftUI
import AVFoundation

struct EditorView: View {
    @EnvironmentObject var store: SongStore
    @State var song: Song

    @State private var player: AVAudioPlayer?
    @State private var playhead: TimeInterval = 0
    @State private var duration: TimeInterval = 0
    @State private var timer: Timer?
    @State private var statusText: String = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Title & key
                VStack(alignment: .leading, spacing: 8) {
                    TextField("Title", text: Binding(
                        get: { activeSong.wrappedValue.title },
                        set: { activeSong.wrappedValue.title = $0; store.save() }
                    ))
                    .textFieldStyle(.roundedBorder)

                    HStack(spacing: 12) {
                        Picker("Key", selection: Binding(
                            get: { activeSong.wrappedValue.key },
                            set: { activeSong.wrappedValue.key = $0; store.save() }
                        )) {
                            ForEach(Key.allCases) { k in Text(k.rawValue).tag(k) }
                        }
                        .pickerStyle(.menu)
                    }
                }

                // Transport
                if let _ = activeSong.wrappedValue.audioURL {
                    transport
                } else {
                    Text("No audio for this song yet. Record in New Capture.")
                        .foregroundStyle(.secondary)
                }

                // Auto-chords
                Button {
                    guard let url = activeSong.wrappedValue.audioURL else { return }
                    do {
                        let events = try ChordSuggester.suggestChords(url: url,
                                                                      songKey: activeSong.wrappedValue.key,
                                                                      spacingSeconds: 2.0)
                        activeSong.wrappedValue.chordEvents = events
                        store.save()
                    } catch {
                        print("Suggest error:", error.localizedDescription)
                    }
                } label: {
                    Label("Auto-Suggest Chords (beta)", systemImage: "wand.and.stars")
                }
                .buttonStyle(.bordered)

                // Preview simple chord list
                if !activeSong.wrappedValue.chordEvents.isEmpty {
                    GroupBox("Suggested Chords") {
                        VStack(alignment: .leading, spacing: 6) {
                            ForEach(activeSong.wrappedValue.chordEvents.indices, id: \.self) { i in
                                let e = activeSong.wrappedValue.chordEvents[i]
                                Text("\(String(format: "%.1f", e.time))s  —  \(e.chord.display)")
                                    .font(.system(.body, design: .monospaced))
                            }
                        }
                    }
                }

                // If you already have these types, you can re-enable:
                /*
                ChordPadView(chordEvents: activeSong.chordEvents, playhead: $playhead)
                Button("Align Chords to Lyrics") {
                    aligned = AlignmentEngine.align(lyrics: activeSong.wrappedValue.lyrics,
                                                    chordEvents: activeSong.wrappedValue.chordEvents)
                }
                */
            }
            .padding()
        }
        .navigationTitle(activeSong.wrappedValue.title)
        .onAppear { preparePlayerIfPossible() }
        .onChange(of: activeSong.wrappedValue.audioURL) { preparePlayerIfPossible() }
        .onDisappear { stop() }
    }

    // MARK: Transport
    private var transport: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Button(action: toggle) {
                    Label(isPlaying ? "Pause" : "Play",
                          systemImage: isPlaying ? "pause.fill" : "play.fill")
                }
                .buttonStyle(.borderedProminent)

                Text(String(format: "%.1f / %.1fs", playhead, duration))
                    .monospacedDigit()
                    .foregroundStyle(.secondary)

                Slider(value: Binding(
                    get: { playhead },
                    set: { newVal in seek(to: newVal) }
                ), in: 0...(duration > 0 ? duration : 1))
            }
            if !statusText.isEmpty {
                Text(statusText).font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    private var isPlaying: Bool { player?.isPlaying == true }

    private func preparePlayerIfPossible() {
        guard let url = activeSong.wrappedValue.audioURL else {
            statusText = "No audio URL."; return
        }
        guard FileManager.default.fileExists(atPath: url.path) else {
            statusText = "Audio file not found at \(url.lastPathComponent)."; return
        }
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            duration = player?.duration ?? 0
            startTimer()
            statusText = "Ready."
        } catch {
            statusText = "Player error: \(error.localizedDescription)"
        }
    }

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
            playhead = player?.currentTime ?? 0
        }
        RunLoop.main.add(timer!, forMode: .common)
    }

    private func toggle() {
        if isPlaying { player?.pause() } else { player?.play() }
    }

    private func seek(to t: TimeInterval) {
        guard let player else { return }
        player.currentTime = max(0, min(t, player.duration))
        playhead = player.currentTime
        if !isPlaying { player.play() }
    }

    private func stop() {
        player?.stop()
        player = nil
        timer?.invalidate()
        timer = nil
    }

    // Bind to the stored song by id (avoids editing a copy)
    private var activeSong: Binding<Song> {
        if let idx = store.songs.firstIndex(where: { $0.id == song.id }) {
            return Binding(
                get: { store.songs[idx] },
                set: { store.songs[idx] = $0; store.save() }
            )
        } else {
            return Binding(
                get: { store.active },
                set: { store.active = $0; store.addActiveToLibrary() }
            )
        }
    }
}
