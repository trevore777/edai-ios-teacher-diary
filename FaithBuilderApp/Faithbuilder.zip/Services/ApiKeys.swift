//
//  ApiKeys.swift
//  FaithBuilderApp
//
//  Created by Trevor Elliott on 20/11/2025.
//


import Foundation

enum ApiKeys {
    /// Replace this with your real ChatGPT API key before building.
    /// Do NOT commit your real key to a public repository.
    static let openAI: String = "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"
}
